/**
 * This example generates TypeScript classes, interfaces, enumerations and structs from Yellicode model 'model/model-based-example.ymn'.  
 */

import { TextWriter } from '@yellicode/core';
import { Generator } from '@yellicode/templating';
import { TypeScriptWriter, OptionalityModifier } from '@yellicode/typescript';
import * as elements from '@yellicode/elements';

Generator.generateFromModel({ outputFile: './output/using-yellicode-model-output.ts' }, (output: TextWriter, model: elements.Model) => {
    const ts = new TypeScriptWriter(output);

    // Classes
    ts.writeRegionBlock('Classes', () => {
        // Write all classes with their properties and methods.
        model.getAllClasses().forEach(cls => {
            ts.writeClassBlock(cls, () => {
                cls.ownedAttributes.forEach(att => {
                    ts.writeProperty(att, { initializePrimitiveType: true, initializeArray: true, optionality: OptionalityModifier.NullKeyword });
                    ts.writeLine();
                });
                cls.ownedOperations.forEach(op => {
                    ts.writeFunctionBlock(op, () => {
                        ts.writeLine(`throw 'This function is not implemented'; // you could delegate the implementation to custom code`);
                    });
                    ts.writeLine();
                });
            }, { export: true });
            ts.writeLine();
        });
    })
    //Enums
    ts.writeLine();
    ts.writeRegionBlock('Enums', () => {
        model.getAllEnumerations().forEach(e => {
            ts.writeEnumeration(e, { export: true });
            ts.writeLine();
        });
    });

    // Interfaces
    ts.writeLine();
    ts.writeRegionBlock('Interfaces', () => {
        model.getAllInterfaces().forEach(i => {
            ts.writeInterfaceBlock(i, () => {
                i.ownedAttributes.forEach(att => {
                    ts.writeProperty(att);
                    ts.writeLine();
                });
                i.ownedOperations.forEach(op => {
                    ts.writeFunctionDeclaration(op);
                    ts.writeLine();
                });
            }, { export: true });
            ts.writeLine();
        });
    });
});     