/**
 * This example generates TypeScript classes from the definitions in a OpenAPI JSON specification (models/petstore-simple.json). 
 * The JSON file is taken from https://github.com/OAI/OpenAPI-Specification/blob/master/examples/v2.0/json/petstore-simple.json.
 */

import { Generator, TextWriter, NameUtility } from '@yellicode/templating';
import { TypeScriptWriter, ClassDefinition, PropertyDefinition } from '@yellicode/typescript';

/**
 * A simple mapper function to turn a OpenAPI type name into a TypeScript type name.
 * @param openApiTypeName 
 */
const mapToTypeScriptTypeName = (openApiTypeName: string): string => {
    switch (openApiTypeName) {
        case 'integer':
            return 'number';      
        default:
            return openApiTypeName;
    }
}

Generator.generateFromModel({ outputFile: './output/using-json-output.ts' }, (output: TextWriter, model: any) => {
    const classDefinitions: ClassDefinition[] = [];

    // Transform OpenAPI definitions to TypeScript definitions
    for (const definition in model.definitions) {
        const value = model.definitions[definition];
        const classDefinition: ClassDefinition = { name: definition, export: true };
        const classProperties: PropertyDefinition[] = [];
        if ('properties' in value) {
            const properties = value['properties'];

            for (const prop in properties) {
                const propName = prop; // if you want UppperCase properties: const propName = NameUtility.lowerToUpperCamelCase(prop);
                const csTypename = mapToTypeScriptTypeName(properties[prop].type);
                classProperties.push({ name: propName, typeName: csTypename, accessModifier: "public" });
            }
        }
        classDefinition.properties = classProperties;
        classDefinitions.push(classDefinition);
    }

    // Then write code from the definition
    const ts = new TypeScriptWriter(output);
    // Write out the class properties
    classDefinitions.forEach(cd => {
        ts.writeClassBlock(cd, () => {
            cd.properties.forEach(p => {
                ts.writeProperty(p);
                ts.writeLine();
            });
        });
        ts.writeLine();
    })
});
