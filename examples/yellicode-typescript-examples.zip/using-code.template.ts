/**
 * This example generates TypeScript classes from definitions that are created inside the template itself.  
 */

import { Generator, TextWriter } from '@yellicode/templating';
import { TypeScriptWriter, ClassDefinition } from '@yellicode/typescript';

Generator.generate({ outputFile: './output/using-code-output.ts' }, (output: TextWriter) => {

    // Sample class definition. You would typically create this definition from a JSON model, see 'using-json.template.ts'.
    const classDefinition: ClassDefinition = {
        name: 'Task',
        export: true,
        description: ['Represents an activity to be done.']
    };

    classDefinition.properties = [
        { name: 'TaskDescription', typeName: 'string', accessModifier: 'public', description: ['Gets or sets a description of the task.'] },
        { name: 'IsFinished', typeName: 'boolean', accessModifier: 'public', description: ['Indicates if the task is finished.'] }
    ];

    const ts = new TypeScriptWriter(output);
    // Write out the class properties
    ts.writeClassBlock(classDefinition, () => {
        classDefinition.properties.forEach(p => {
            ts.writeProperty(p);
            ts.writeLine();
        })
    });
});
